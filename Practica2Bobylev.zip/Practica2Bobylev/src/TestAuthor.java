public class TestAuthor {
    public static void main(String[] args) {
        Author a1 = new Author("Darya Doncova", "DDoncova@mail.ru", 'F');
        System.out.println(a1);
        Author a2 = new Author("Valentin Rasputin", "VRasputin@gmail.com", 'M');
        System.out.println(a2);
        Author a3 = new Author("Victor Astafiev", "VAstafiev@yandex.ru", 'M');
        System.out.println(a3);
    }
}
